#!/bin/bash

# Отключаем set -e, чтобы мы могли сами ловить ошибки и отправлять алерты
set -uo pipefail

cd /root/workout-bot
mkdir -p backups

# Загружаем переменные окружения из .env (безопасно)
if [ -f .env ]; then
    set -a
    source .env
    set +a
else
    echo "Ошибка: файл .env не найден!"
    exit 1
fi

BACKUP_FILE="backups/backup_$(date +%Y-%m-%d).sql"

# 1. Делаем дамп базы данных
if ! docker compose exec -T db sh -c 'pg_dump -U bot_user -d workout_bot' > "$BACKUP_FILE"; then
    curl -sS -F "chat_id=${CHAT_ID}" \
        -F "text=🚨 ОШИБКА: pg_dump упал! БД не создалась ($(date))" \
        "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" || true
    exit 1
fi

# 2. Проверка: файл создался и не пустой?
if [ ! -s "$BACKUP_FILE" ]; then
    curl -sS -F "chat_id=${CHAT_ID}" \
        -F "text=🚨 ОШИБКА: бэкап пустой ($(date))" \
        "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" || true
    exit 1
fi

# 3. Отправка в Telegram (с красивой подписью)
if ! curl -fsS \
    -F "chat_id=${CHAT_ID}" \
    -F "document=@${BACKUP_FILE}" \
    -F "caption=✅ <b>Ежедневный бэкап</b> базы <code>workout_bot</code> за $(date +%d.%m.%Y)" \
    -F "parse_mode=HTML" \
    "https://api.telegram.org/bot${BOT_TOKEN}/sendDocument"; then
    curl -sS -F "chat_id=${CHAT_ID}" \
        -F "text=🚨 ОШИБКА: не удалось отправить бэкап в Telegram ($(date))" \
        "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" || true
    exit 1
fi

# 4. Отправка в Яндекс.Диск
if ! rclone copy "${BACKUP_FILE}" yandex:vps/hostkey/backups/; then
    curl -sS -F "chat_id=${CHAT_ID}" \
        -F "text=🚨 ОШИБКА: не удалось отправить бэкап в Яндекс.Диск ($(date))" \
        "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" || true
    exit 1
fi

# 5. Удаление старых бэкапов (локально и в облаке)
find backups/ -name "backup_*.sql" -mtime +30 -delete
rclone delete yandex:vps/hostkey/backups/ --min-age 30d

# 6. Финальное сообщение об успехе
echo "✅ Бэкап за $(date) успешно создан, отправлен в TG и Яндекс.Диск."
curl -sS -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
     --data-urlencode "chat_id=${CHAT_ID}" \
     --data-urlencode "text=📦 Файл сохранен в TG и Яндекс.Диск.
🧹 Старые копии (старше 30 дней) удалены." || true
